import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function Cadastro() {
  const [cadastroData, setCadastroData] = useState({
    nome: "",
    sobrenome: "",
    email: "",
    senha: "",
    telefone: 0,
  });

  const handleCadastro = async (e) => {
    e.preventDefault();

    try {
      await axios.post("https://localhost:7280/api/Usuario", cadastroData);
      // Lógica de redirecionamento após o cadastro bem-sucedido
      console.log("Cadastro bem-sucedido!");
    } catch (error) {
      console.error("Erro no cadastro:", error);
    }
  };

  return (
    <div>
      <h2>Cadastro</h2>
      <form onSubmit={handleCadastro}>
        <input
          type="text"
          placeholder="Nome"
          value={cadastroData.nome}
          onChange={(e) => setCadastroData({ ...cadastroData, nome: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Sobrenome"
          value={cadastroData.sobrenome}
          onChange={(e) => setCadastroData({ ...cadastroData, sobrenome: e.target.value })}
          required
        />
        <input
          type="email"
          placeholder="Email"
          value={cadastroData.email}
          onChange={(e) => setCadastroData({ ...cadastroData, email: e.target.value })}
          required
        />
        <input
          type="password"
          placeholder="Senha"
          value={cadastroData.senha}
          onChange={(e) => setCadastroData({ ...cadastroData, senha: e.target.value })}
          required
        />
        <input
          type="number"
          placeholder="Telefone"
          value={cadastroData.telefone}
          onChange={(e) => setCadastroData({ ...cadastroData, telefone: e.target.value })}
          required
        />
       <Link to="/"><button type="submit" >Cadastrar</button></Link>
      </form>
    </div>
  );
}

export default Cadastro;