import React, { useState, useEffect } from "react";
import axios from "axios";

function QuadraComentarios({ quadraId }) {
  const [comentarios, setComentarios] = useState([]);

  useEffect(() => {
    // Fazer a request para obter os comentários da quadra
    axios
      .get(`https://localhost:7280/api/Comentario/${quadraId}`)
      .then((response) => {
        setComentarios(response.data);
      })
      .catch((error) => {
        console.error("Erro ao obter comentários:", error);
      });
  }, [quadraId]);

  return (
    <div>
      <h2>Comentários da Quadra</h2>
      <ul>
        {comentarios.map((comentario) => (
          <li key={comentario.id}>{comentario.texto}</li>
        ))}
      </ul>
    </div>
  );
}

export default QuadraComentarios;