import React, { useEffect, useState } from 'react';
import axios from 'axios';

function AvaliacoesPorQuadra() {
  const [avaliacoes, setAvaliacoes] = useState([]);
  const [quadras, setQuadras] = useState({});
  const [nota, setNota] = useState({});
  const [avaliacoesPorQuadra, setAvaliacoesPorQuadra] = useState({});

  useEffect(() => {
    // Solicitar dados de avaliação
    axios.get('https://localhost:7280/api/avaliacao')
      .then((response) => {
        setAvaliacoes(response.data);


       console.log(response.data)

        // Processar dados e contar avaliações positivas por quadra
        const avaliacoesQuadra = {};
        //const nota = 
        response.data.forEach((avaliacao) => {
            //console.log(avaliacao.IdQuadra)
          const idQuadra = avaliacao.idQuadra;
          const nota = avaliacao.nota;
          setNota(nota);
        //  const idUsuario = avaliacao.idUsuario;
          //console.log(idQuadra)
          if (!avaliacoesQuadra[idQuadra]) {
            avaliacoesQuadra[idQuadra] = 0;
          }
          if (avaliacao.Nota > 3) {
            avaliacoesQuadra[idQuadra]++;
          }
        });

        setAvaliacoesPorQuadra(avaliacoesQuadra);
       

        // Solicitar nomes das quadras
        const quadraIds = Object.keys(avaliacoesQuadra);
        const quadraRequests = quadraIds.map((quadraId) =>
          axios.get(`https://localhost:7280/api/quadra/${quadraId}`)
        );

        // Processar os dados das quadras
        Promise.all(quadraRequests)
          .then((quadraResponses) => {
            const quadraData = {};

        // console.log(quadraResponses)
            quadraResponses.forEach((quadraResponse, index) => {
              const idQuadra = quadraIds[index];
              quadraData[idQuadra] = quadraResponse.data.nome;
              
            });
            setQuadras(quadraData);
          })
          .catch((error) => {
            console.error('Erro ao obter dados das quadras:', error);
          });
      })
      .catch((error) => {
        console.error('Erro ao obter dados de avaliação:', error);
      });
  }, []);
  

  // Renderizar o gráfico aqui usando a biblioteca de gráficos de sua escolha
  return (
    <div>
        <h1>TESTE</h1>

      {Object.keys(avaliacoesPorQuadra).map((idQuadra) => (
    <div key={idQuadra}>
    <p>Quadra: {quadras[idQuadra]}</p>
    <p>Nota: {nota}</p>
  
  </div>
))}
</div>
);
      }

export default AvaliacoesPorQuadra;

//  <p>Avaliações Positivas: {avaliacoesPorQuadra[idQuadra]}</p>