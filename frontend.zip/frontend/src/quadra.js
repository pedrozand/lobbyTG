import { Link,useParams } from 'react-router-dom';
import React, { useState, useEffect } from "react";
import axios from "axios";
import './CSS/quadra.css';
import './CSS/StarRating.css';
import './CSS/quadra2.css';

//import QuadraComentarios from './Comentario';
//import dataManager from "./DataManager";
function numeroParaEstrelas(numero) {
  if (numero < 0 || numero > 5) {
    return ''; // Retorna uma string vazia se o número estiver fora do intervalo
  }

  return '★'.repeat(numero); // Cria uma string com estrelas com base no número
}

const renderStars = (averageRating) => {
  const stars = [];
  for (let i = 0; i < averageRating; i++) {
    stars.push(<span key={i}>&#9733;</span>); // &#9733; é a entidade HTML para estrela
  }
  return stars;
};
function Quadra() {
  const { id } = useParams();
  const [quadraData, setQuadraData] = useState({});
  const [userRating, setUserRating] = useState(0); // Avaliação do usuário
  const [averageRating, setAverageRating] = useState(0); // Média das avaliações
  const [userComment, setUserComment] = useState([]);
  const [comentarios, setComentarios] = useState([]);

  localStorage.setItem('quadraId', id);
//  dataManager.set('quadraId', id);



  
  useEffect(() => {
    // Carregue os detalhes da quadra e as avaliações dos usuários
    axios.get(`https://localhost:7280/api/Quadra/${id}`)
      .then((response) => {
        setQuadraData(response.data);
       // setAverageRating(response.data.avaliacaoQuadra);
      })
      .catch((error) => {
        console.error("Erro ao realizar a solicitação:", error);
      });

      axios.get(`https://localhost:7280/api/Avaliacao/media/${id}`)
      .then((response) => {
        setAverageRating(response.data);
       // setAverageRating(response.data.avaliacaoQuadra);
      })
      .catch((error) => {
        console.error("Erro ao realizar a solicitação:", error);
      });


      

      const submitRating = (nota, quadraId) => {
        var userId = localStorage.getItem('userId');
       // var userId2 = dataManager.get('userId');
       // console.log("por meio de classe"+userId2)

        userId = parseInt(userId)
        nota = nota + 1
    
     //   console.log(typeof nota)
     //   console.log(typeof userId)
     //   console.log(typeof quadraId)
        
        const notaObj = {
          IdUsuario: userId,
          IdQuadra: quadraId, 
          Nota: nota
        };
      
     //   console.log(notaObj)
    
    //    const response = axios.post(
      //    "https://localhost:7280/api/Avaliacao",
        // notaObj
       // );
    
         axios.post(`https://localhost:7280/api/Avaliacao`, 
        notaObj)
          .then((response) => {
            // Supondo que a média seja retornada diretamente pela API como 'media'
          //  setAverageRating(response.data.media);
        //    console.log("Avaliado com sucesso!");
          })
          .catch((error) => {
            console.error("Erro ao enviar a avaliação:", error);
          });
      };

   

  }, [id]);

  const handleRatingChange = (event) => {
    setUserRating(parseInt(event.target.value));
  };
  const submitComment = (comment, quadraId) => {
    const userId = localStorage.getItem("userId");
    const commentObj = {
      IdUsuario:userId,
      IdQuadra:quadraId,
      ComentarioCompleto:comment,
    };
  
    // Verifique se o usuário já fez um comentário para a mesma quadra
   //versao antiga https://localhost:7280/api/Comentario/${userId}/${quadraId}
   console.log("teste"+quadraId+"e"+userId)
    axios
      .get(`https://localhost:7280/api/Comentario/GetComentarioPorIds?idQuadra=${quadraId}&idUsuario=${userId}`)
      .then((response) => {
        console.log(response)
        if (response.data.length > 0) {
          // O usuário já fez um comentário para esta quadra
          alert("Você já fez um comentário para esta quadra.");
        } else {
          // O usuário pode adicionar um novo comentário
          console.log(commentObj)
          axios
            .post("https://localhost:7280/api/Comentario", commentObj)
            .then((response) => {
              if (response.status === 200) {
                alert("Comentário adicionado com sucesso");
                setUserComment("");
              } else {
                alert("Erro ao adicionar comentário");
              }
            })
            .catch((error) => {
              console.error("Erro ao enviar o comentário:", error);
              alert("Erro ao adicionar comentário");
            });
        }
      })
      .catch((error) => {
        console.error("Erro ao verificar comentário existente:", error);
        alert("Erro ao verificar comentário existente");
      });
  };
  
  const submitRating = async (nota, quadraId) => {
    try {
      var userId = localStorage.getItem('userId');
    //  var userId2 = dataManager.get('userId');
     // console.log("por meio de classe"+userId2)

      userId = parseInt(userId);

   //   console.log(typeof nota);
   //   console.log(typeof userId);
   //   console.log(typeof quadraId);

      const notaObj = new Object();

      notaObj.IdUsuario = userId;
      notaObj.IdQuadra = quadraId;
      notaObj.Nota = nota;

    //  console.log(notaObj);
  
      const response = await axios.post(`https://localhost:7280/api/Avaliacao`, notaObj);

      if (response.status === 200) {
        // A avaliação foi adicionada com sucesso.
        alert("Avaliação adicionada com sucesso");
      } else if (response.status === 400) {
        // A solicitação foi bem-sucedida, mas a API retornou um erro.
        alert("ja registrado"); // Exibe a mensagem de erro da API.
      } else {
        // Outros tratamentos de erro, se necessário.
        alert("ja adicionou seu comentario")
      }
   
     // console.log("Avaliado com sucesso!");
    } catch (error) {
      console.error("Erro ao enviar a avaliação:", error);
      alert("comentario ja adicionado")
    }
  };

  useEffect(() => {
    
    // Fazer a request para obter os comentários da quadra
    axios
      .get(`https://localhost:7280/api/Comentario/TodosComentarios/${id}`)
      .then((response) => {
        setComentarios(response.data);
        console.log(response.data)
      })
      .catch((error) => {
        console.error("Erro ao obter comentários:", error);
      });
  }, [id]);

  return (
    <div >
  
        <div class="corpo">
        <img className="QuadraImage" src={quadraData.imagem} alt={quadraData.nome} />
       <div className="QuadraTitle">
      <h3> {quadraData.nome} </h3>
      <br></br>
     
      <p>Horário de Funcionamento: <strong>{quadraData.horarioFuncionamento}</strong></p>
      <br></br>
      <p>Endereço: <strong>{quadraData.endereco}</strong></p>
      <br></br>
     

     
     <h1 className="Avaliacao">Avaliação da Quadra: {renderStars(parseInt(averageRating.toFixed(1)))}</h1>
     <div>
      <br></br>
        <label>Sua Avaliação:</label>
        <select value={userRating} onChange={handleRatingChange}>
          <option value={1}>★</option>
          <option value={2}>★★</option>
          <option value={3}>★★★</option>
          <option value={4}>★★★★</option>
          <option value={5}>★★★★★</option>
        </select>
        <button onClick={() => submitRating(userRating, quadraData.quadraId)}>Enviar Avaliação</button>

      <br></br>     
      </div>

     <br></br>


     
      </div>
      
      
     
      {/* Exibe estrelas para a avaliação do usuário */}
    
        <ul className="comment-list">
        
        {comentarios.length > 0 ? (
          comentarios.map((comentario) => (
            <li className="comment-item" > <span className="user-name">{" nome: "+comentario.nomeUsuario}</span> <span className="comment-text">{"    - comentario: "+comentario.comentarioCompleto}</span></li>
          ))
        ) : (
          <p>Nenhum comentário disponível.</p>
        )}
      </ul>   

     


       


      <div>
      <br></br>
      <textarea 
            value={userComment}
            onChange={(e) => setUserComment(e.target.value)}
            placeholder="Adicione um comentário..."
        ></textarea>




      </div>
      
      <button onClick={() => submitComment(userComment, quadraData.quadraId)}>
                        Enviar Comentário
        </button>
        <h1>___</h1>
     
      <Link to='/lobby'><button>Ir para o Lobby</button></Link>





        </div>
       



       
    </div>
  );
}

export default Quadra;
//   <h1 className="QuadraTitle">Informações da Quadra</h1>
// <p>Descrição: <strong>{quadraData.descricao}</strong></p>
//    <p>Modalidades: <strong>{quadraData.modalidades}</strong></p>
// <p className="Avaliacao">Avaliação da Quadra: {averageRating.toFixed(1)} estrelas</p>
//<p className="Avaliacao">Avaliação da Quadra: {averageRating} estrelas</p>
//<p className="Avaliacao">Avaliação da Quadra: {numeroParaEstrelas(parseInt(averageRating.toFixed(1)))}</p>




/*

 <div>
      <br></br>
        <label>Sua Avaliação:</label>
        <select value={userRating} onChange={handleRatingChange}>
          <option value={1}>★</option>
          <option value={2}>★★</option>
          <option value={3}>★★★</option>
          <option value={4}>★★★★</option>
          <option value={5}>★★★★★</option>
        </select>
        <button onClick={() => submitRating(userRating, quadraData.quadraId)}>Enviar Avaliação</button>

      <br></br>     
      </div>

    

     
      <h1>   ___  </h1>
    <br></br>
      <textarea 
            value={userComment}
            onChange={(e) => setUserComment(e.target.value)}
            placeholder="Adicione um comentário..."
        ></textarea>
        <button onClick={() => submitComment(userComment, quadraData.quadraId)}>
                        Enviar Comentário
        </button>

*/
