import React from 'react';
import { Link } from 'react-router-dom';
import './CSS/HorariosGrid.css';


const HorariosGrid = () => {
  const horarios = Array.from({ length: 16 }, (_, i) => {
    const hora = i + 6; // Começando às 9:00
    const horario = `${hora}:00-${hora + 1}:00`;
    const horarioLink = `${hora}-${hora + 1}`;
    
    return (
      <div key={i} className="horario-block">
        <Link to={`/lobby/${horarioLink}`} className="horario-link">
          {horario}
        </Link>
      </div>
    );
  });

  return <div className="horarios-grid">{horarios}</div>;
};

export default HorariosGrid;