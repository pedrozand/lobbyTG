import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Map from './mapComponent.js';
import MarkerPage from './quadra';
import CrudQuadra from './CRUD/CRUDquadra.js';
import CrudUsuarios from './CRUD/CRUDusuario.js';
import CrudLobby from './CRUD/CRUDlobby.js';
import './CSS/App.css';
import Cadastro from './Cadastro.js';
import Login from './Login.js';
import HorariosGrid from './HorariosGrid.js';
import NovoLobby from './NovoLobby.js';
import ADM from './ADM.js';
import Grafico from './Grafico.js';
import ErrorBoundary from './Error.js';


function App() {

  return (
    <div className="App">
       
      <BrowserRouter>
      <ErrorBoundary>
        <Routes>

          <Route path="/quadra/:id" element={<MarkerPage />} />

          <Route path="/ADM" element={<ADM />} />

          <Route path="/CrudQuadra" element={<CrudQuadra />} />

          <Route path="/CrudUsuarios" element={<CrudUsuarios />} />

          <Route path="/CrudLobby" element={<CrudLobby />} />

          <Route path="/" element={<Login/>} />

          <Route path="/Cadastro" element={<Cadastro />} />

          <Route path="/lobby/:hora" element={<NovoLobby/>} />

          <Route path="/lobby" element={<HorariosGrid/>} />

          <Route path="/mapa" element={<Map />} />

          <Route path="/Avalicoes" element={<Grafico />} />

        </Routes>
        </ErrorBoundary>
      </BrowserRouter>
      
    </div>
  );
}

export default App;