// Login.js

import React, { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "./CSS/login.css";
//import "./CSS/geral.css";
//import dataManager from "./DataManager.js";
//import userStore from "./UserStore"; // Importe a classe de armazenamento do usuário
//import { useUser } from './UserContext'; 


function Login() {
  //const { setUserId } = useUser(); // Obtenha a função setUserId do contexto
  const [loginData, setLoginData] = useState({
    email: "",
    senha: "",
  });

  const handleLogin = async (e) => {
    e.preventDefault();
    console.log(loginData)
    try {
      const response = await axios.post(
        "https://localhost:7280/api/Usuario/Login",
        loginData
      );

      if (response.status === 200) {
        const userData = response.data;
        console.log("Login bem-sucedido!");
        //console.log(response)
        // Use o método setUser da classe de armazenamento para salvar o usuário
      //  userStore.setUser(userData);

      const userId = userData.usuarioId;

      // Armazene o `userId` no localStorage
      console.log(userId)
      localStorage.setItem('userId', userId);
     // dataManager.set('userId', userId);

        console.log("o user data e o"+userData)

     if (userData.adm) {
      // Se for um ADM, redirecione para a página do ADM
      window.location.href = "/ADM";
    } else {
      // Caso contrário, redirecione para a página do mapa
      window.location.href = "/mapa";
    }
      } else {
        console.error("Erro no login:", response.data);
        alert("Erro no login. Verifique suas credenciais.");
      }
    } catch (error) {
      console.error("Erro no login:", error);
      alert("Erro no login. Verifique suas credenciais.");
    }
    
  };

  return (
    <div class='main-div'>
     
          <div class="logo">
          <h1>Login</h1>
          </div>
      <form onSubmit={handleLogin}>
      
     

       <div class="div-input">
          
          <input type="email" placeholder="Email" value={loginData.email}
          onChange={(e) =>
            setLoginData({ ...loginData, email: e.target.value })
          } required 
          />
       </div>

       <div class="div-input">
         
          <input type="password" placeholder="Senha"
          value={loginData.senha}
          onChange={(e) =>
            setLoginData({ ...loginData, senha: e.target.value })
          }
          required
        />
       </div>

       <div class="div-btn-login">
         <button class="btn-login" type="submit">Entrar</button>
          <span>Caso nao possua uma conta registre em: <Link to="/cadastro"><a>cadastro</a></Link></span>
       </div>
        
      </form>
    
    </div>
  );
}

export default Login;
