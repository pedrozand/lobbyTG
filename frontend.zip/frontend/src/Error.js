import React, { Component } from 'react';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  componentDidCatch(error, info) {
    this.setState({ hasError: true });
  }

  render() {
    if (this.state.hasError) {
      // Redirecionar para uma página de erro personalizada ou uma página vazia
      return this.props.children;
    }
    return this.props.children;
  }
}

export default ErrorBoundary;