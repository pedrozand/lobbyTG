import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import "./CSS/lobby.css";
import "./CSS/botao.css";
//import dataManager from "./DataManager";

function ReservaConfirmacao() {
  const { hora } = useParams();
  const [lobby, setLobby] = useState([]);
  const [lista, setLista] = useState([]);
  const [usuario, setUsuario] = useState(null);
  const [detalhesJogadores, setDetalhesJogadores] = useState({});
  const [confirmacaoJogadores, setconfirmacaoJogadores] = useState({});
  const [quadra, setQuadra] = useState(null);
  const [userLocation, setUserLocation] = useState(null);
  const [distance, setDistance] = useState(null);
  const [confirmacao, setConfirmacao] = useState(null);
  const [confirmacaoUsuario, setConfirmacaousuario] = useState(null);

  // Função para buscar detalhes de um jogador com base no ID do jogador
  const buscarDetalhesDoJogador = async (jogadorId) => {
    try {
      const response = await axios.get(
        `https://localhost:7280/api/Usuario/${jogadorId}`
      );
      return response.data.nome;
    } catch (error) {
      console.error("Erro ao buscar detalhes do jogador:", error);
      return "vazio";
    }
  };

  useEffect(() => {
    const IdQuadra = localStorage.getItem('quadraId');
    const userId = localStorage.getItem('userId');
    checkUserConfirmationUsuario(userId)
   // var userId2 = dataManager.get('userId');
   // var IdQuadra2 = dataManager.get('quadraId');
   // console.log("por meio de classe"+userId2+IdQuadra2)


    if (userId) {
      axios.get(`https://localhost:7280/api/Usuario/${userId}`)
        .then((response) => {
          setUsuario(response.data);
        })
        .catch((error) => {
          console.error("Erro ao buscar usuário:", error);
        });
    }

    axios.get(`https://localhost:7280/api/lobby/quadra/${IdQuadra}`)
      .then(async (response) => {
        const lobbysDaAPI = response.data;
        const listaFiltrada = lobbysDaAPI.filter((item) => item.hora === hora);

        if (listaFiltrada.length > 0) {
          const lobby = listaFiltrada[0];
          setLobby(lobby);

          const JogadoresId = lobby.jogadoresId;

          const response = await axios.get(
            `https://localhost:7280/api/Jogador/${JogadoresId}`
          );

          const jogadoresId = response.data;

          const jogadoresArray = Object.values(jogadoresId);

          const jogadoresRestantes = jogadoresArray.slice(1);

          const jogadoresTransformados = jogadoresRestantes
            .filter((jogador) => typeof jogador === "number")
            .map((jogador) => ({ id: jogador }));

          setLista(jogadoresTransformados);
        }
      })
      .catch((error) => {
        console.error("Erro ao buscar jogadores:", error);
      });

    // Buscar detalhes da quadra
    const fetchQuadraDetails = () => {
      const IdQuadra = 1; // Substitua pelo ID da quadra desejada

      if (IdQuadra) {
        axios
          .get(`https://localhost:7280/api/quadra/${IdQuadra}`)
          .then((response) => {
            setQuadra(response.data);
          })
          .catch((error) => {
            console.error("Erro ao buscar quadra:", error);
          });
      }
    };

    // Obter localização do usuário
    const fetchUserLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            setUserLocation({ latitude, longitude });
          },
          (error) => {
            console.error("Erro ao obter a localização:", error);
          }
        );
      } else {
        console.error("Geolocalização não suportada pelo navegador.");
      }
    };

    // Chamar funções para buscar detalhes da quadra e localização do usuário
    fetchQuadraDetails();
    fetchUserLocation();
  }, [hora]);

  useEffect(() => {
    // Buscar detalhes de todos os jogadores na lista
    if (lista.length > 0) {
      const detalhesPromises = lista.map((jogador) => {
        return buscarDetalhesDoJogador(jogador.id);
      });

      Promise.all(detalhesPromises)
        .then((detalhes) => {
          const detalhesJogadoresAtualizados = {};

          lista.forEach((jogador, index) => {
            detalhesJogadoresAtualizados[jogador.id] = detalhes[index];
          });

          console.log("detalhes:"+detalhesJogadoresAtualizados)
          setDetalhesJogadores(detalhesJogadoresAtualizados);
        })
        .catch((error) => {
          console.error("Erro ao buscar detalhes dos jogadores:", error);
        });
    }
  }, [lista]);

  const adicionarUsuario = () => {
    if (usuario) {
      // Verifica se o usuário já está na lista
      const usuarioExistente = lista.find((item) => item.id === usuario.usuarioId);

      if (!usuarioExistente) {
        const indiceZero = lista.findIndex((item) => item.id === 0);

        if (indiceZero !== -1) {
          lista[indiceZero].id = usuario.usuarioId;
        } else {
          console.log('Não há lugar vazio na lista.');
        }

        const novaLista = lista;
        const novaListaJson = novaLista.map((id) => ({
          id
        }));

        const listaDeObjetos = Object.values(novaListaJson);

        const objetoTransformado = {};

        listaDeObjetos.forEach((item, index) => {
          const chave = `jogador${index + 1}`;
          const valor = item.id.id;
          objetoTransformado[chave] = valor;
        });

        const jogadoresid = lobby.jogadoresId;
        objetoTransformado.jogadoresId = jogadoresid;

        // Atualize a lista localmente
        setLista(novaLista);

        console.log(objetoTransformado)
        // Faz a solicitação PUT para a API de Jogador com a nova lista completa
        axios.put(`https://localhost:7280/api/Jogador/${jogadoresid}`, objetoTransformado)
          .then((response) => {
            console.log("Lista de jogadores atualizada com sucesso!");
            alert('Jogador adicionado com sucesso');
          })
          .catch((error) => {
            console.error("Erro ao atualizar a lista de jogadores:", error);
          });
      } else {
        alert('O usuário já está na lista.');
      }
    } else {
      console.log('Ainda não carregou o usuário da API');
    }

    // Verificar a distância após a reserva
   // calculateDistance();
  };

  const calculateDistance = () => {
    if (quadra && userLocation) {
      const { latitude: lat1, longitude: lon1 } = quadra;
      const { latitude: lat2, longitude: lon2 } = userLocation;

      const radlat1 = (Math.PI * lat1) / 180;
      const radlat2 = (Math.PI * lat2) / 180;
      const theta = lon1 - lon2;
      const radtheta = (Math.PI * theta) / 180;

      let calculatedDistance =
        Math.sin(radlat1) * Math.sin(radlat2) +
        Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
      calculatedDistance = Math.acos(calculatedDistance);
      calculatedDistance = (calculatedDistance * 180) / Math.PI;
      calculatedDistance = calculatedDistance * 60 * 1.1515;

      setDistance(calculatedDistance);

      // Verificar se a distância é menor que 10 milhas antes de confirmar
      if (calculatedDistance < 10) {
        confirmarReserva();
      } else {
        alert("A distância é maior que 10 milhas. Não é possível confirmar.");
      }
    }
  };

  const confirmarReserva = async () => {
    // Antes de confirmar a reserva, verifique se o usuário já confirmou anteriormente
    const confirmacaoExistente = await checkUserConfirmation(usuario.usuarioId);
  console.log(confirmacaoExistente)
    if (confirmacaoExistente) {
      console.log("Você já confirmou a reserva anteriormente.");
      // Lógica adicional, se necessário
    } else {
      const confirmacaoObj = {
        IdUsuario: usuario.usuarioId,
        IdLobby: lobby.lobbyId,
        Confirmado: true,
      };
  
      try {
        const response = await axios.post(
          "https://localhost:7280/api/Confirmacao",
          confirmacaoObj
        );
  
        if (response.status === 200) {
          console.log("Reserva confirmada com sucesso!");
          setConfirmacao(true);
          alert("Reserva confirmada com sucesso!");
        } else {
          console.error("Erro ao confirmar a reserva:", response.data);
          alert("Reserva ja esta feita");
        }
      } catch (error) {
        console.error("Erro ao confirmar a reserva:", error);
        alert("Reserva ja esta feita");
      }
    }
  };
  

  // Função para verificar a confirmação do usuário
  const checkUserConfirmation = () => {
    //console.log(id)
    const idUsuario = usuario.usuarioID;
    const idLobby = lobby.lobbyId;
  
    var confirmacaoRetorno 

    axios
      .get(
        `https://localhost:7280/api/confirmacao/GetConfirmacaoPorIds?idLobby=${idLobby}&idUsuario=${idUsuario}`
      )
      .then((response) => {

         confirmacaoRetorno = response.data
        if(response.status === 200){
            console.log(response.data)
           // setConfirmacao(response.data);
           //confirmacaoRetorno = true
           setConfirmacaousuario(true)
        }
        else{
            //confirmacaoRetorno = false
            setConfirmacaousuario(false)
        }

        console.log("Confirmação do usuário:", response.data);
        setConfirmacao(response.data);
      })
      .catch((error) => {
        console.error("Erro ao verificar a confirmação do usuário:", error);
      });
      
  };

  const checkUserConfirmationUsuario = (id) => {
    //console.log(id)
    const idUsuario = id;
    const idLobby = lobby.lobbyId;
  
    var confirmacaoRetorno 

    axios
      .get(
        `https://localhost:7280/api/confirmacao/GetConfirmacaoPorIds?idLobby=${idLobby}&idUsuario=${idUsuario}`
      )
      .then((response) => {

         confirmacaoRetorno = response.data
        if(response.status === 200){
            console.log(response.data)
           // setConfirmacao(response.data);
           //confirmacaoRetorno = true
           setConfirmacaousuario(true)
        }
        else{
            //confirmacaoRetorno = false
            setConfirmacaousuario(false)
        }

        console.log("Confirmação do usuário:", response.data);
        setConfirmacaousuario(response.data);
      })
      .catch((error) => {
        console.error("Erro ao verificar a confirmação do usuário:", error);
      });
      
  };




  const buscarConfirmacoesDosJogadores = async (jogadores) => {
    const confirmacoes = {};
  
    for (const jogador of jogadores) {
      const jogadorId = jogador.id;
  
      // Implemente a lógica para buscar a confirmação do jogador com base no ID
      // Você pode usar uma chamada de API semelhante à busca de detalhes dos jogadores
      const confirmacao = await buscarConfirmacaoDoJogador(jogadorId);
  
      confirmacoes[jogadorId] = confirmacao;
    }
  
    return confirmacoes;
  };

  const buscarConfirmacaoDoJogador = async (jogadorId) => {
    const idLobby = lobby.lobbyId;
    try {
      // Implemente a chamada de API para buscar a confirmação do jogador com base no ID
      const response = await axios.get(
        `https://localhost:7280/api/confirmacao/GetConfirmacaoPorIds?idLobby=${idLobby}&idUsuario=${jogadorId}`
      );
  
      return "confirmado"; // Supondo que a confirmação seja um valor que você pode obter da resposta
    } catch (error) {
      console.error("Erro ao buscar confirmação do jogador:", error);
      return "nao confirmado"; // Ou algum valor padrão, se a busca falhar
    }
  };

  useEffect(() => {
    if (lista.length > 0) {
      buscarConfirmacoesDosJogadores(lista)
        .then((confirmacoes) => {
          setconfirmacaoJogadores(confirmacoes);
        })
        .catch((error) => {
          console.error("Erro ao buscar confirmações dos jogadores:", error);
        });
    }
  }, [lista]);

 
  return (
    <div>
      <h2>Hora: {hora}</h2>
      <h2>Lista de Reserva</h2>
      <div className="grid-container">
        {lista.map((jogador) => (
          <div className="grid-item" key={jogador.id}>
           <img className="imagemIcone" src="https://img.myloview.com.br/adesivos/icone-de-pessoas-icone-de-pessoa-icone-de-usuario-no-elegante-estilo-plano-isolado-700-150665401.jpg"/>
            <h4>Jogador: { detalhesJogadores[jogador.id]}</h4>
            <h4>Confirmação: {confirmacaoJogadores[jogador.id]}</h4>
          </div>
        ))}
      </div>
      <button class="btn" onClick={adicionarUsuario}>Reservar</button>
      {confirmacaoUsuario != true  && (
        <button class="btn" onClick={calculateDistance}>confirmar</button>
        
        //calculateDistance
      )}
      {confirmacaoUsuario === true && (
        <p>Reserva confirmada com sucesso!</p>
      )}
      {distance !== null && (
        <p>A distância entre você e a quadra é aproximadamente {distance.toFixed(2)} milhas.</p>
      )}
    </div>
  );
}

export default ReservaConfirmacao;



  //useEffect(() => {
    // Verificar a confirmação do usuário após a reserva
    //if (usuario && lobby) {
     // checkUserConfirmation(usuario.usuarioId);
    //}
  //}, [usuario, lobby]);
  // <p>ID: {jogador.id}</p>