import React, { useEffect, useState } from 'react';
import GoogleMapReact from 'google-map-react';
import axios from 'axios';
import './CSS/mapa.css';
import './CSS/quadra2.css';

const MapComponent = () => {
  const [quadras, setQuadras] = useState([]);
  const defaultCenter = {
    lat: -22.925133730865817,
    lng: -46.561556599100534,
  };

  useEffect(() => {
    axios.get('https://localhost:7280/api/Quadra')
      .then((response) => {
        setQuadras(response.data);
      })
      .catch((error) => {
        console.error('Erro ao obter dados das quadras:', error);
      });
  }, []);

  const handleMarkerClick = (quadraId) => {
    // Redireciona para outra página ao clicar no marcador
    console.log("funcionando")
    window.location.href = `http://localhost:3000/quadra/${quadraId}`;
  };

  const renderMarkers = (map, maps) => {
    quadras.forEach((quadra) => {
      const marker = new maps.Marker({
        position: { lat: parseFloat(quadra.latitude), lng: parseFloat(quadra.longitude) },
        map,
        title: quadra.nome,
      });

      marker.addListener('click', () => {
        handleMarkerClick(quadra.quadraId);
      });
    });
  };

  return (
  
  <div className="map-container">
      <div className="lobby">
        <h1>Mapa</h1>

    
        <div class="logo2">
        
        </div>
        <div class="corpo2">


        <div id="map" className="map">
        <GoogleMapReact
        bootstrapURLKeys={{ key: 'AIzaSyA50vU7Gq5fKgDiwun9zrcnLphxSP-5hU4' }} // Substitua pela sua chave da API do Google Maps
        defaultCenter={defaultCenter}
        defaultZoom={11}
        yesIWantToUseGoogleMapApiInternals
        onGoogleApiLoaded={({ map, maps }) => {
          renderMarkers(map, maps);
        }}
      />

        </div>
      </div>
      </div>
   
   
     
    </div>
  );
};

export default MapComponent;