import React, { useState, useEffect } from "react";
import axios from "axios";
import "../CSS/login.css";

function QuadraCRUD() {
  const [quadras, setQuadras] = useState([]);
  const [quadraData, setQuadraData] = useState({
    nome: "",
    descricao: "",
    horarioFuncionamento: "",
    // Adicione outros campos aqui
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchQuadras();
  }, []);

  const fetchQuadras = async () => {
    try {
      const response = await axios.get("https://localhost:7280/api/Quadra");
      setQuadras(response.data);
    } catch (error) {
      console.error("Erro ao buscar quadras:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (isEditing) {
        await axios.put(`https://localhost:7280/api/Quadra/${editingId}`, quadraData);
        setIsEditing(false);
      } else {
        await axios.post("https://localhost:7280/api/Quadra", quadraData);
      }

      fetchQuadras();
      setQuadraData({
        nome: "",
        descricao: "",
        horarioFuncionamento: "",
        // Limpe outros campos aqui
      });
    } catch (error) {
      console.error("Erro ao enviar os dados:", error);
    }
  };

  const handleEdit = (quadra) => {
    setQuadraData(quadra);
    setIsEditing(true);
    setEditingId(quadra.QuadraId);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`https://localhost:7280/api/Quadra/${id}`);
      fetchQuadras();
    } catch (error) {
      console.error("Erro ao excluir a quadra:", error);
    }
  };

  return (
    <div>

      <div class="logo">
          <h1>Quadra</h1>
          </div>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Nome"
          value={quadraData.nome}
          onChange={(e) => setQuadraData({ ...quadraData, nome: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Descrição"
          value={quadraData.descricao}
          onChange={(e) => setQuadraData({ ...quadraData, descricao: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Horário de Funcionamento"
          value={quadraData.horarioFuncionamento}
          onChange={(e) => setQuadraData({ ...quadraData, horarioFuncionamento: e.target.value })}
          required
        />
        {/* Adicione outros campos do formulário aqui */}
        <button type="submit">{isEditing ? "Editar" : "Adicionar"}</button>
      </form>

      <h2>Quadras</h2>
      <ul>
        {quadras.map((quadra) => (
          <li key={quadra.QuadraId}>
            {quadra.nome} ({quadra.descricao}){" "}
            <button onClick={() => handleEdit(quadra)}>Editar</button>
            <button onClick={() => handleDelete(quadra.QuadraId)}>Excluir</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default QuadraCRUD;