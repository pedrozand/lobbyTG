import React, { useState, useEffect } from "react";
import axios from "axios";
import "../CSS/login.css";

function UsuarioCRUD() {
  const [usuarios, setUsuarios] = useState([]);
  const [usuarioData, setUsuarioData] = useState({
    nome: "",
    sobrenome: "",
    email: "",
    senha: "",
    telefone: 0,
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchUsuarios();
  }, []);

  const fetchUsuarios = async () => {
    try {
      const response = await axios.get("https://localhost:7280/api/Usuario");
      setUsuarios(response.data);
    } catch (error) {
      console.error("Erro ao buscar usuários:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (isEditing) {
        await axios.put(`https://localhost:7280/api/Usuario/${editingId}`, usuarioData);
        setIsEditing(false);
      } else {
        await axios.post("https://localhost:7280/api/Usuario", usuarioData);
      }

      fetchUsuarios();
      setUsuarioData({
        nome: "",
        sobrenome: "",
        email: "",
        senha: "",
        telefone: 0,
      });
    } catch (error) {
      console.error("Erro ao enviar os dados:", error);
    }
  };

  const handleEdit = (usuario) => {
    setUsuarioData(usuario);
    setIsEditing(true);
    setEditingId(usuario.UsuarioId);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`https://localhost:7280/api/Usuario/${id}`);
      fetchUsuarios();
    } catch (error) {
      console.error("Erro ao excluir o usuário:", error);
    }
  };

  return (
    <div>
      

      <div class="logo">
          <h1>Usuário</h1>
          </div>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Nome"
          value={usuarioData.nome}
          onChange={(e) => setUsuarioData({ ...usuarioData, nome: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Sobrenome"
          value={usuarioData.sobrenome}
          onChange={(e) => setUsuarioData({ ...usuarioData, sobrenome: e.target.value })}
          required
        />
        <input
          type="email"
          placeholder="Email"
          value={usuarioData.email}
          onChange={(e) => setUsuarioData({ ...usuarioData, email: e.target.value })}
          required
        />
        <input
          type="password"
          placeholder="Senha"
          value={usuarioData.senha}
          onChange={(e) => setUsuarioData({ ...usuarioData, senha: e.target.value })}
          required
        />
        <input
          type="number"
          placeholder="Telefone"
          value={usuarioData.telefone}
          onChange={(e) => setUsuarioData({ ...usuarioData, telefone: e.target.value })}
          required
        />
        <button type="submit">{isEditing ? "Editar" : "Adicionar"}</button>
      </form>

      <h2>Usuários</h2>
      <ul>
        {usuarios.map((usuario) => (
          <li key={usuario.UsuarioId}>
            {usuario.nome} {usuario.sobrenome} ({usuario.email}){" "}
            <button onClick={() => handleEdit(usuario)}>Editar</button>
            <button onClick={() => handleDelete(usuario.UsuarioId)}>Excluir</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default UsuarioCRUD;