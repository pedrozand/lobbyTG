import React, { useState, useEffect } from "react";
import axios from "axios";
import "../CSS/login.css";

function LobbyCRUD() {
  const [lobbies, setLobbies] = useState([]);
  const [lobbyData, setLobbyData] = useState({
    hora: "",
    idQuadra: 0,
    jogadoresId: 0,
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchLobbies();
  }, []);

  const fetchLobbies = async () => {
    try {
      const response = await axios.get("https://localhost:7280/api/Lobby");
      setLobbies(response.data);
    } catch (error) {
      console.error("Erro ao buscar lobbies:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (isEditing) {
        await axios.put(`https://localhost:7280/api/Lobby/${editingId}`, lobbyData);
        setIsEditing(false);
      } else {
        await axios.post("https://localhost:7280/api/Lobby", lobbyData);
      }

      fetchLobbies();
      setLobbyData({
        hora: "",
        idQuadra: 0,
        jogadoresId: 0,
      });
    } catch (error) {
      console.error("Erro ao enviar os dados:", error);
    }
  };

  const handleEdit = (lobby) => {
    setLobbyData(lobby);
    setIsEditing(true);
    setEditingId(lobby.LobbyId);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`https://localhost:7280/api/Lobby/${id}`);
      fetchLobbies();
    } catch (error) {
      console.error("Erro ao excluir o lobby:", error);
    }
  };

  return (
    <div>
      <div class="logo">
          <h1>Lobby</h1>
          </div>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Hora"
          value={lobbyData.hora}
          onChange={(e) => setLobbyData({ ...lobbyData, hora: e.target.value })}
          required
        />
        <input
          type="number"
          placeholder="ID da Quadra"
          value={lobbyData.idQuadra}
          onChange={(e) => setLobbyData({ ...lobbyData, idQuadra: e.target.value })}
          required
        />
        <input
          type="number"
          placeholder="ID dos Jogadores"
          value={lobbyData.jogadoresId}
          onChange={(e) => setLobbyData({ ...lobbyData, jogadoresId: e.target.value })}
          required
        />
        <button type="submit">{isEditing ? "Editar" : "Adicionar"}</button>
      </form>

      <h2>Lobbies</h2>
      <ul>
        {lobbies.map((lobby) => (
          <li key={lobby.LobbyId}>
            Hora: {lobby.hora}, Quadra ID: {lobby.idQuadra}, Jogadores ID: {lobby.jogadoresId}{" "}
            <button onClick={() => handleEdit(lobby)}>Editar</button>
            <button onClick={() => handleDelete(lobby.LobbyId)}>Excluir</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default LobbyCRUD;
