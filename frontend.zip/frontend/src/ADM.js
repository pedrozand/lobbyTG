import React from 'react';
import { Link } from 'react-router-dom';
import axios from "axios";

function NavigationPage() {

  const limpar = () => {

    axios
      .get(
        `https://localhost:7280/api/confirmacao/LimparJogadores`
      )
      .then((response) => {

         //confirmacaoRetorno = response.data
        if(response.status === 200){
            console.log(response.data)
           // setConfirmacao(response.data);
           //confirmacaoRetorno = true
           //setConfirmacaousuario(true)
          }
        else{
            //confirmacaoRetorno = false
         //   setConfirmacaousuario(false)
         console.log("nao deu 200")
        }

        console.log("Confirmação do usuário:", response.data);
       // setConfirmacaousuario(response.data);
      })
      .catch((error) => {
        console.error("Erro ao limpar:", error);
      });
      
  };

  return (
    <div>
      <h2>Página de Navegação</h2>
      <div>
        <Link to="/CrudQuadra">
          <button>Gerenciar Quadras</button>
        </Link>
      </div>
      <br></br>
      <div>
        <Link to="/CrudUsuarios">
          <button>Gerenciar Usuários</button>
        </Link>
      </div>
      <br></br>
      <div>
        <Link to="/CrudLobby">
          <button>Gerenciar Lobby</button>
        </Link>
      </div>
      <br></br>
      <div>
        <Link to="/Avalicoes">
          <button>Dashboard Avaliçoes</button>
        </Link>
      </div>
     
      <br></br>
      <div>
          <button onClick={limpar}>Limpar os Jogadores</button>
      </div>
    </div>
    
    
  );
}

export default NavigationPage;


/*

 <br></br>
      <div>
        <Link >
          <button>Dashboard Lobby</button>
        </Link>
      </div>
      <br></br>
      <div>
        <Link >
          <button>Dashboard Usuarios</button>
        </Link>
      </div>
      <br></br>
      <div>
        <Link >
          <button>Dashboard Avaliaçoes</button>
        </Link>
      </div>
*/