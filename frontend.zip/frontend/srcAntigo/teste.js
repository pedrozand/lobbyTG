import React, { useEffect, useState } from 'react';
import GoogleMapReact from 'google-map-react';
import axios from 'axios';

const AnyReactComponent = ({ text }) => <div>{text}</div>;

const MapComponent = () => {
  const [quadras, setQuadras] = useState([]);
  const defaultProps = {
    center: {
      lat: -22.925133730865817, // Latitude inicial do mapa
      lng: -46.561556599100534, // Longitude inicial do mapa
    },
    zoom: 11,
  };

  useEffect(() => {
    // Fazer a requisição à API e obter os dados das quadras usando o Axios
    axios.get('https://localhost:7280/api/Quadra')
      .then((response) => {
        setQuadras(response.data); // Define os dados das quadras no estado
      })
      .catch((error) => {
        console.error('Erro ao obter dados das quadras:', error);
      });
  }, []);

  return (
    <div style={{ height: '400px', width: '100%' }}>
      <GoogleMapReact
        bootstrapURLKeys={{ key: 'AIzaSyA50vU7Gq5fKgDiwun9zrcnLphxSP-5hU4' }} // Substitua pela sua chave da API do Google Maps
        defaultCenter={defaultProps.center}
        defaultZoom={defaultProps.zoom}
      >
        {quadras.map((quadra) => (
          <AnyReactComponent
            key={quadra.quadraId}
            lat={parseFloat(quadra.latitude)}
            lng={parseFloat(quadra.longitude)}
            text={quadra.nome}
          />
        ))}
      </GoogleMapReact>
    </div>
  );
};

export default MapComponent;